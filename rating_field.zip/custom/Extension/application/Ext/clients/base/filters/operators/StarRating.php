<?php

$viewdefs['base']['filter']['operators']['Ratingfield'] = array(
    '$equals' => 'LBL_OPERATOR_EQUALS',
    '$not_equals' => 'LBL_OPERATOR_NOT_EQUALS',
    '$in' => 'LBL_OPERATOR_CONTAINS',
    '$gt' => 'LBL_OPERATOR_GREATER_THAN',
    '$lt' => 'LBL_OPERATOR_LESS_THAN',
    '$gte' => 'LBL_OPERATOR_GREATER_THAN_OR_EQUALS',
    '$lte' => 'LBL_OPERATOR_LESS_THAN_OR_EQUALS',
    '$between' => 'LBL_OPERATOR_BETWEEN',
);

<?php
$mod_strings['fieldTypes']['Ratingfield'] = 'Rating (stars)';
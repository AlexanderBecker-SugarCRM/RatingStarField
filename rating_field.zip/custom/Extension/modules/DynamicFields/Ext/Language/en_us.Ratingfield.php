<?php
$mod_strings['Ratingfield'] = 'Rating (stars)';
$mod_strings['LBL_RATINGFIELD_FORMAT_HELP'] = '';

$mod_strings['LBL_RATINGFIELD_COLOR'] = 'Color';